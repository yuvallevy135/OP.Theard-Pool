//
// Created by yuvallevy on 20/05/2020.
//
#include <stdio.h>
#include <stdbool.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <dirent.h>
#include <time.h>

#define NO_C_FILE "0"
#define COMPILATION_ERROR "10"
#define TIMEOUT "20"
#define WRONG "50"
#define SIMILAR "75"
#define EXCELLENT "100"

typedef struct InputDataStruct {
    int check;
    char *studentPath;
    char *myInputPath;
    char *correctPath;
} InputDataStruct;

InputDataStruct createDataStruct(char *argv[]);

int createMemberFromInput(int fDirIn, char *member);

int checkFilesInStudent(char *nextDir, InputDataStruct myDataStruct, char *studentName,bool firstLine);

int tryToCompileFile(char *filePath, char *myInput);

int resCsv(char *studentName, char* score,bool firstLine);
int runExe(char* myInput);
int getCompareResult(char* solFile,char* correctFile);

int createMemberFromInput(int fDirIn, char *member) {
    char buffer[1];
    int firstChar, i = 0;
    member = (char *) calloc(151, sizeof(char));
    while (true) {
        firstChar = read(fDirIn, buffer, 1);
        if (firstChar < 0) {
            write(2, "Error in system call\n", 25);
            return -1;
        }
        if (firstChar == '\n') {
            break;
        }
        member[i] = buffer[0];
        i++;
    }
    return 0;
}

InputDataStruct createDataStruct(char *argv[]) {
    InputDataStruct myDataStruct;
    int allGoodResult;
    int fDirIn = open(argv[1], O_RDONLY);
    if (fDirIn < 0) {
        write(2, "Not a valid directory\n", 25);
        myDataStruct.check = -1;
        close(fDirIn);
        return myDataStruct;
    }
    myDataStruct.check = 0;
    myDataStruct.check = createMemberFromInput(fDirIn, myDataStruct.studentPath);
    myDataStruct.check = createMemberFromInput(fDirIn, myDataStruct.myInputPath);
    myDataStruct.check = createMemberFromInput(fDirIn, myDataStruct.correctPath);
    if (myDataStruct.check == -1) {
        close(fDirIn);
        return myDataStruct;
    }
    close(fDirIn);
    return myDataStruct;
}

int tryToCompileFile(char *filePath, char *myInput) {
    pid_t pid;
    int status;
    // Create a new process.
    if ((pid = fork()) < 0) {
        write(2, "Error in system call\n", 25);
        return -1;
    }
    else {
        if (pid == 0) {
            char *gcc[] = {"gcc", "myExecFile.out", filePath, NULL};
            // The child process.
            if (execvp(gcc[0], gcc) == -1) {
                write(2, "Error in system call\n", 25);
                return -1;
            }
            //return 0;
        } else {
            // The parent process.
            wait(&status);
            if (WEXITSTATUS(status) == 0) {
                // Worked.
                return 0;
            }
        }
    }
    return 1;
}
int resCsv(char* studentName,char* score, bool firstLine){
    int fileD;
    if((fileD = open("results.csv",O_CREAT | O_APPEND | O_RDONLY,0644)) < 0){
        write(2, "Error in system call\n", 25);
        return -1;
    }
    char myLine[160] ={0};
    if(!firstLine){
        strcat(myLine,"\n");
        strcat(myLine,studentName);
    }else{
        firstLine=false;
        strcat(myLine,studentName);
    }
    strcat(myLine,",");
    strcat(myLine,score);
    strcat(myLine,",");
    if(strcmp(score,NO_C_FILE)==0){strcat(myLine,"0");}
    else if (strcmp(score,COMPILATION_ERROR)==0){strcat(myLine,"10");}
    else if (strcmp(score,TIMEOUT)==0){strcat(myLine,"20");}
    else if (strcmp(score,WRONG)==0){strcat(myLine,"50");}
    else if (strcmp(score,SIMILAR)==0){strcat(myLine,"75");}
    else if (strcmp(score,EXCELLENT)==0){strcat(myLine,"100");}
    else{strcat(myLine,"100");}
    if(write(fileD,myLine,strlen(myLine))){
        write(2, "Error in system call\n", 25);
        return -1;
    }
    return 1;
}
int runExe(char* myInput){
    pid_t pid;
    int status;
    time_t startT, endT;
    double cpuTime = 0;
    int newFdIn,newFdOut;
    // Create a new process.
    if ((pid = fork()) < 0) {
        write(2, "Error in system call\n", 25);
        return -1;
    }
    else {
        if (pid == 0) {
            if ((newFdIn = open(myInput, O_RDONLY, 0644)) < 0){
                write(2, "Error in system call\n", 25);
                return -1;
            }
            if ((newFdOut = open("results.txt", O_CREAT | O_TRUNC | O_RDWR, 0644)) < 0){
                write(2, "Error in system call\n", 25);
                return -1;
            }
            dup2(newFdIn, 0);
            dup2(newFdOut, 1);
            close(newFdIn);
            close(newFdOut);
            char* run[] = {"./myExecFile.out",myInput,NULL};
            if (execvp(run[0], run) == -1) {
                write(2, "Error in system call\n", 25);
                return -1;
            }
        } else  {
            // The parent process.
            while (waitpid(pid, &status, WNOHANG) != pid) {
                time(&endT);
                cpuTime = difftime(endT, startT);
                // if the execution time lasted more than 5 seconds return 1
                if (cpuTime > 3) {
                    kill(pid, SIGKILL);
                    wait(NULL);
                    return 1;
                }
            }
            return 0;
        }
    }
    return 1;
}
int getCompareResult(char* solFile,char* correctFile){
    pid_t pid;
    int status;
    // Create a new process.
    if ((pid = fork()) < 0) {
        write(2, "Error in system call\n", 25);
        return -1;
    }
    else {
        if (pid == 0) {
            char *compare[] = {"./comp.out", solFile, correctFile, NULL};
            // The child process.
            if (execvp(compare[0], compare) == -1) {
                write(2, "Error in system call\n", 25);
                return -1;
            }
            return 1;
        } else {
            // The parent process.
            do {
                waitpid(pid, &status, WUNTRACED);
            } while ((!WIFEXITED(status) && !WIFSIGNALED(status)));
        }
    }
    return WEXITSTATUS(status);
}

int checkFilesInStudent(char *nextDir, InputDataStruct myDataStruct, char *studentName,bool firstLine) {
    struct dirent *directoryP;
    DIR *dir;
    // Try to open the path bc its not a directory for sure.
    if ((dir = opendir(nextDir)) == NULL) {
        while ((directoryP = readdir(dir)) != NULL) {
            if (directoryP->d_type == DT_REG && strcmp(directoryP->d_name, ".") != 0 &&
                strcmp(directoryP->d_name, "..") != 0) {
                // Check if the file is '.c' file.
                char *fileName = directoryP->d_name;
                if ((fileName[strlen(fileName) - 2] == '.') && (fileName[strlen(fileName) - 1] == 'c')) {
                    char fileInDir[155] = {0};
                    strcat(fileInDir, nextDir);
                    strcat(fileInDir, "/");
                    strcat(fileInDir, directoryP->d_name);
                    int compileRes = tryToCompileFile(fileInDir, myDataStruct.myInputPath);
                    if (compileRes == -1 || compileRes == 1) {
                        closedir(dir);
                        // System call error.
                        if (compileRes == -1) {
                            return -1;
                        }
                        // Compile call error. Need to add it to the rcv with grade of 10.
                        resCsv(studentName, "10",&firstLine);
                        closedir(dir);
                        return 1;
                    }
                    if (runExe(myDataStruct.myInputPath) == 1) {
                        resCsv(studentName, "20",&firstLine);
                        closedir(dir);
                        return 1;
                    }
                    int res = getCompareResult("results.txt",myDataStruct.correctPath);
                    if(res ==1){
                        // same.
                        resCsv(studentName, "100",&firstLine);
                        closedir(dir);
                        return 1;
                    } else if(res == 3){
                        // Half similar
                        resCsv(studentName, "75",&firstLine);
                        closedir(dir);
                        return 1;
                    }else if (res == 2){
                        resCsv(studentName, "50",&firstLine);
                        closedir(dir);
                        return 1;
                        // Different.
                    }
                    else{
                        resCsv(studentName, "0",&firstLine);
                        closedir(dir);
                        return 0;
                    }
                }
            }
        }
    }
    else{
        write(2, "Error in system call\n", 25);
        closedir(dir);
        return -1;
    }
}


int main(int argc, char *argv[]) {
    struct dirent *directoryP;
    DIR *dir;
    // Check that we get 1 args.
    if (argc != 2) {
        printf("Invalid input\n");
        return 0;
    }
    InputDataStruct myDataStruct = createDataStruct(argv);
    if (myDataStruct.check == -1) {
        return 0;
    }
    bool firstLine=true;
    // Try to open the path bc its not a directory for sure.
    if ((dir = opendir(myDataStruct.studentPath)) == NULL) {
        while ((directoryP = readdir(dir)) != NULL) {
            if (directoryP->d_type == DT_DIR && strcmp(directoryP->d_name, ".") != 0 &&
                strcmp(directoryP->d_name, "..") != 0) {
                char nextDir[155] = {0};
                int resultCheckFilesInStudent;
                strcat(nextDir, myDataStruct.studentPath);
                strcat(nextDir, "/");
                strcat(nextDir, directoryP->d_name);
                checkFilesInStudent(nextDir, myDataStruct, directoryP->d_name, &firstLine);
            }
        }
        remove("myExecFile.out");
        remove("results.txt");
    }
    return 0;

}