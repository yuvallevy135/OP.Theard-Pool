//
// Created by yuvallevy on 20/05/2020.
//

#include <stdio.h>
#include <stdbool.h>
#include <fcntl.h>
#include <unistd.h>

int getFileSize(int fileDirIn);

int seekStart(int fDin, int i);

int checkIfSimilar(int firstDirIn, int secondDirIn);

int checkIfHalfSimilar(int firstDirIn, int secondDirIn,int  sizeBiggerFile, int sizeSmallerFile);


int checkIfSimilar(int firstDirIn, int secondDirIn) {
    char firstDirBuffer[1] = {0}, secondDirBuffer[1] = {0};
    int shouldStop = 0, checkSeek1, checkSeek2;
    int firstDirChar, secondDirChar;
    while (!shouldStop){
        firstDirChar = read(firstDirIn, firstDirBuffer, 1);
        secondDirChar = read(secondDirIn, secondDirBuffer, 1);

        // Check if both of my files returned something.
        if(firstDirChar >0 && secondDirChar > 0){
            if(firstDirBuffer[0] != secondDirBuffer[0]){
                return 0;
            }
        }else{
            shouldStop=1;
        }
    }
    if (firstDirChar == -1 || secondDirChar == -1){
        write(2, "Error in system call\n", 21);
        return -1;
    }
    checkSeek1 = seekStart(firstDirIn,0);
    checkSeek2 = seekStart(secondDirIn,0);
    if (checkSeek1 == -1 || checkSeek2 == -1){
        return -1;
    }
    return 1;
}

int checkIfHalfSimilar(int biggerDirIn, int smallerDirIn,int  sizeBiggerFile, int sizeSmallerFile){
    int similarGoal;
    if(sizeBiggerFile <= sizeSmallerFile){
         similarGoal = (sizeBiggerFile+1)/2;
    }else{
         similarGoal = (sizeSmallerFile+1)/2;
    }
    int seek1, seek2;
    //int firstDirChar, secondDirChar;
    int i,j,round;
    for (i=0;i<sizeBiggerFile;i++){
        int firstDirChar=0, secondDirChar=0;
        int counter=0;
        char firstDirBuffer[sizeBiggerFile-i], secondDirBuffer[sizeSmallerFile];
        firstDirChar = read(biggerDirIn, firstDirBuffer, sizeBiggerFile-i);
        secondDirChar = read(smallerDirIn, secondDirBuffer, sizeSmallerFile);
        // Check if both of my files returned something.
        if(firstDirChar >0 && secondDirChar > 0) {
            if(sizeBiggerFile-i <= sizeSmallerFile){
                round = sizeBiggerFile-i;
            }else{
                round = sizeSmallerFile;
            }
            for(j=0;j<round;j++){
                if(firstDirBuffer[j] == secondDirBuffer[j]){
                    counter++;
                }
            }
            if(counter >= similarGoal){
                return 1;
            }
        }
        seek1 = seekStart(biggerDirIn,i+1);
        seek2 = seekStart(smallerDirIn,0);
        if (seek1 == -1 || seek2 == -1){
            write(2, "Error in system call\n", 21);
            return -1;
        }
    }
    seek1 = seekStart(biggerDirIn,0);
    return 2;
}



int seekStart(int fDin, int i) {
    int check;
    check = lseek(fDin, i, SEEK_SET);
    if (check == -1) {
        write(2, "Error in system call\n", 21);
        return -1;
    }
    return 1;
}

int getFileSize(int fileDirIn) {
    int readFromFile;
    char readBuffer[1] = {0};
    bool shouldStop = true;
    int charCounter = 0;
    int begin;
    // Read char by char from file.
    while (shouldStop) {
        readFromFile = read(fileDirIn, readBuffer, 1);
        if (readFromFile == 0) {
            shouldStop=false;
        } else {
            charCounter++;
        }
    }
    // If error happened while trying to read from file.
    if (readFromFile == -1) {
        write(2, "Error in system call\n", 21);
        return -1;
    }
    // Go back to the beginning of the file.
    begin = seekStart(fileDirIn,0);
    if (begin == -1) {
        return -1;
    }
    return charCounter;
}


int main(int argc, char *argv[]) {

    int firstDirIn, secondDirIn;
    int sizeFileOne, sizeFileSecond;
    int checkSimilar, checkIsHalfSimilar1,checkIsHalfSimilar2;

    // Check that we get 2 args.
    if (argc != 3) {
        //printf("Invalid input\n");
        return 0;
    }
    // Open both of the files.
    firstDirIn = open(argv[1], O_RDONLY);
    secondDirIn = open(argv[2], O_RDONLY);
    if (firstDirIn < 0) {
        close(firstDirIn);
    }
    if (secondDirIn < 0) {
        close(secondDirIn);
    }
    // Get the size of the 2 files.
    sizeFileOne = getFileSize(firstDirIn);
    sizeFileSecond = getFileSize(secondDirIn);

    // check if the files are the same or if error happened.
    if (sizeFileOne == sizeFileSecond) {
        checkSimilar = checkIfSimilar(firstDirIn, secondDirIn);
        // check if they are the same
        if (checkSimilar == 1) {
            printf("same");
            close(firstDirIn);
            close(secondDirIn);
            return 1;
            // check if error happened.
        } else if (checkSimilar == -1) {
            close(firstDirIn);
            close(secondDirIn);
            return 0;
        }
    }
    // check if the are half same

//    if(sizeFileOne >= sizeFileSecond){
//        checkIsHalfSimilar = checkIfHalfSimilar(firstDirIn, secondDirIn, sizeFileOne, sizeFileSecond);
//    } else{
//        checkIsHalfSimilar = checkIfHalfSimilar(secondDirIn, firstDirIn,sizeFileSecond,sizeFileOne);
//    }
    checkIsHalfSimilar1 = checkIfHalfSimilar(firstDirIn, secondDirIn, sizeFileOne, sizeFileSecond);
    checkIsHalfSimilar2 = checkIfHalfSimilar(secondDirIn, firstDirIn,sizeFileSecond,sizeFileOne);

    // They are half similar.
    if(checkIsHalfSimilar1 == 1 || checkIsHalfSimilar2 == 1){
        close(firstDirIn);
        close(secondDirIn);
        printf("half-similar");
        return 3;
        // They are different.
    }else if(checkIsHalfSimilar1 == 2 && checkIsHalfSimilar2 ==2){
        printf("different");
        close(firstDirIn);
        close(secondDirIn);
        return 2;
        // There was an error.
    }else{
        close(firstDirIn);
        close(secondDirIn);
        return 0;
    }
}